const listEndpoints = require('express-list-endpoints');
console.table(listEndpoints(app)); 